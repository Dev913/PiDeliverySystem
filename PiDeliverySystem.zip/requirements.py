from os import system
system('sudo pip install pyyaml')
system('sudo pip install picamera')
system('sudo pip3 install twilio')
system('sudo pip3 install pip')
system('sudo pip install twilio')
system('sudo pip3 install google_speech')